# Build the launcher APK on your PC (alternative: let GitHub Actions build it, see README).
# Needs: JDK 17+ and the Android SDK (easiest way to get both: install Android Studio once).
. "$PSScriptRoot\common.ps1"

$launcher = Join-Path $Script:Kit 'launcher'
Write-Host "`n== Build launcher ==" -ForegroundColor Cyan

# Java
$java = Get-Command java -ErrorAction SilentlyContinue
if (-not $java) {
    $studioJbr = 'C:\Program Files\Android\Android Studio\jbr'
    if (Test-Path "$studioJbr\bin\java.exe") { $env:JAVA_HOME = $studioJbr; $env:Path = "$studioJbr\bin;$env:Path" }
    else { throw 'Java not found. Install Android Studio (it bundles a JDK) or a JDK 17+.' }
}

# Android SDK
$sdk = $env:ANDROID_HOME
if (-not $sdk) { $sdk = $env:ANDROID_SDK_ROOT }
if (-not $sdk -and (Test-Path "$env:LOCALAPPDATA\Android\Sdk")) { $sdk = "$env:LOCALAPPDATA\Android\Sdk" }
if (-not $sdk) { throw 'Android SDK not found. Install Android Studio and open it once (it downloads the SDK), then re-run.' }
$sdkEscaped = $sdk -replace '\\', '/'
"sdk.dir=$sdkEscaped" | Set-Content -Encoding ASCII (Join-Path $launcher 'local.properties')
Write-Host "SDK: $sdk"

Push-Location $launcher
try {
    $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    try { & .\gradlew.bat --no-daemon assembleRelease } finally { $ErrorActionPreference = $old }
    if ($LASTEXITCODE -ne 0) { throw "Gradle build failed (exit $LASTEXITCODE). Send me the red error text and I will fix the source." }
} finally { Pop-Location }

$apk = Join-Path $launcher 'app\build\outputs\apk\release\app-release.apk'
if (-not (Test-Path $apk)) { throw "Build finished but $apk is missing." }
$dist = Join-Path $Script:Kit 'dist'
New-Item -ItemType Directory -Force $dist | Out-Null
Copy-Item $apk (Join-Path $dist 'tvkit-home.apk') -Force
Write-Host "`nBuilt: $dist\tvkit-home.apk  ($([math]::Round((Get-Item $apk).Length / 1MB, 1)) MB)" -ForegroundColor Green
Write-Host 'Next: 03-install-launcher.ps1' -ForegroundColor Cyan
