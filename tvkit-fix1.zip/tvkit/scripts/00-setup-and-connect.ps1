# Step 0: get adb, find the Hisense TV on your Wi-Fi, connect, and confirm with a screenshot.
# Run from PowerShell:  powershell -ExecutionPolicy Bypass -File .\00-setup-and-connect.ps1
. "$PSScriptRoot\common.ps1"

Write-Host "`n== Step 0: adb + connect to your TV ==" -ForegroundColor Cyan
Write-Host @"
On the TV first (once):
  Settings > Device Preferences > About > tap 'Build' 7 times
  Settings > Device Preferences > Developer options > turn on USB debugging / Network debugging
  (Android 11+: 'Wireless debugging' is shown instead and has a pairing code.)
"@

# --- 1. adb --------------------------------------------------------------
$adb = Get-AdbPath
if (-not $adb) {
    Write-Host 'adb not found, downloading Google platform-tools...'
    $zip = Join-Path $Script:Work 'platform-tools.zip'
    Invoke-WebRequest 'https://dl.google.com/android/repository/platform-tools-latest-windows.zip' -OutFile $zip
    Expand-Archive $zip -DestinationPath $Script:Kit -Force
    Remove-Item $zip
    $adb = Get-AdbPath
}
if (-not $adb) { throw 'Could not get adb.exe.' }
AdbRaw start-server | Out-Null
Write-Host "Using adb: $adb"

# --- 2. find candidates (anything listening on 5555 in your /24) ------------
function Find-AdbHosts {
    $prefixes = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Where-Object { $_.IPAddress -notmatch '^(127|169\.254)\.' } |
        ForEach-Object { $_.IPAddress -replace '\.\d+$', '' } | Sort-Object -Unique
    $found = @()
    foreach ($p in $prefixes) {
        Write-Host "Scanning $p.0/24 for devices with network debugging on (port 5555)..."
        $jobs = 1..254 | ForEach-Object {
            $c = New-Object System.Net.Sockets.TcpClient
            [pscustomobject]@{ Ip = "$p.$_"; Client = $c; Task = $c.ConnectAsync("$p.$_", 5555) }
        }
        Start-Sleep -Milliseconds 2000
        foreach ($j in $jobs) {
            if ($j.Task.IsCompleted -and -not $j.Task.IsFaulted -and $j.Client.Connected) { $found += $j.Ip }
            $j.Client.Close()
        }
    }
    return $found
}

function Get-DeviceProp([string]$Serial, [string]$Prop) {
    ((AdbRaw -s $Serial shell getprop $Prop) -join '').Trim()
}

$serial = $null
$hosts = @(Find-AdbHosts)
$candidates = @()
foreach ($h in $hosts) {
    AdbRaw connect "${h}:5555" | Out-Null
    $maker = Get-DeviceProp "${h}:5555" 'ro.product.manufacturer'
    $model = Get-DeviceProp "${h}:5555" 'ro.product.model'
    if ($maker -or $model) { $candidates += [pscustomobject]@{ Serial = "${h}:5555"; Maker = $maker; Model = $model } }
}

if ($candidates.Count -gt 0) {
    Write-Host "`nFound:"
    for ($i = 0; $i -lt $candidates.Count; $i++) {
        $c = $candidates[$i]
        $tag = if ($c.Maker -match 'hisense') { '  <-- Hisense' } else { '' }
        Write-Host ("  [{0}] {1}  {2} {3}{4}" -f ($i + 1), $c.Serial, $c.Maker, $c.Model, $tag)
    }
    $pick = Read-Host 'Pick a number (or press Enter to type an address yourself)'
    if ($pick -match '^\d+$' -and [int]$pick -ge 1 -and [int]$pick -le $candidates.Count) {
        $serial = $candidates[[int]$pick - 1].Serial
    }
}

# --- 3. manual entry / pairing ---------------------------------------------
if (-not $serial) {
    Write-Host "`nNothing auto-detected (or you chose manual)."
    Write-Host 'TV IP is under Settings > Device Preferences > About > Status > IP address.'
    $addr = (Read-Host 'TV address, e.g. 192.168.1.50 or 192.168.1.50:5555').Trim()
    if ($addr -notmatch ':') { $addr = "${addr}:5555" }
    if (Ask-YesNo 'Does your TV show a pairing code (Wireless debugging, Android 11+)?' $false) {
        $pairAddr = (Read-Host 'Pairing address shown on the TV (ip:port)').Trim()
        $code = (Read-Host 'Pairing code').Trim()
        AdbRaw pair $pairAddr $code | ForEach-Object { Write-Host $_ }
    }
    AdbRaw connect $addr | ForEach-Object { Write-Host $_ }
    $serial = $addr
}

# --- 4. authorisation --------------------------------------------------------
for ($try = 1; $try -le 6; $try++) {
    $st = ((AdbRaw -s $serial get-state) -join '').Trim()
    if ($st -eq 'device') { break }
    Write-Host "State: '$st'. Look at the TV: choose ALLOW and tick 'Always allow from this computer'." -ForegroundColor Yellow
    Start-Sleep -Seconds 5
    AdbRaw connect $serial | Out-Null
}
$st = ((AdbRaw -s $serial get-state) -join '').Trim()
if ($st -ne 'device') { throw "Could not get an authorised connection to $serial (state '$st')." }

Set-StateValue 'serial' $serial
Set-StateValue 'connectedAt' (Get-Date).ToString('s')

$maker   = Get-DeviceProp $serial 'ro.product.manufacturer'
$model   = Get-DeviceProp $serial 'ro.product.model'
$android = Get-DeviceProp $serial 'ro.build.version.release'
Write-Host "`nConnected: $maker $model  (Android $android)  at $serial" -ForegroundColor Green
if ($maker -notmatch 'hisense') {
    Write-Warning "This device does not report itself as Hisense ($maker). Check it is the right TV before going on."
    if (-not (Ask-YesNo 'Continue with this device?' $false)) { throw 'Stopped by user.' }
}

# Wake the TV and prove the link with a picture.
Adb shell input keyevent KEYCODE_WAKEUP | Out-Null
$null = Save-Shot '00-connected'
Write-Host "`nLook at the screenshot above to confirm it shows your TV. Next: 01-backup.ps1" -ForegroundColor Cyan
