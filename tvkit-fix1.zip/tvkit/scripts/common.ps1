# Shared helpers, dot-sourced by every script:  . "$PSScriptRoot\common.ps1"
# (Rebuilt from how the other scripts use it; Windows PowerShell 5.1+ compatible.)
$ErrorActionPreference = 'Stop'
$Script:Kit       = Split-Path -Parent $PSScriptRoot
$Script:Work      = Join-Path $Script:Kit 'work'
$Script:Shots     = Join-Path $Script:Work 'screenshots'
$Script:StateFile = Join-Path $Script:Work 'state.json'
foreach ($d in @($Script:Work, $Script:Shots)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
}

# Returns the path to adb.exe, or $null if there is none yet (00-setup-and-connect downloads it).
function Get-AdbPath {
    $local = Join-Path $Script:Kit 'platform-tools\adb.exe'
    if (Test-Path $local) { return $local }
    $cmd = Get-Command adb -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    foreach ($root in @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT, "$env:LOCALAPPDATA\Android\Sdk")) {
        if ($root) {
            $p = Join-Path $root 'platform-tools\adb.exe'
            if (Test-Path $p) { return $p }
        }
    }
    return $null
}

function Read-State {
    if (Test-Path $Script:StateFile) {
        try { return (Get-Content $Script:StateFile -Raw | ConvertFrom-Json) } catch { }
    }
    return [pscustomobject]@{}
}

function Set-StateValue([string]$Name, $Value) {
    $s = Read-State
    if ($s.PSObject.Properties[$Name]) { $s.$Name = $Value }
    else { $s | Add-Member -NotePropertyName $Name -NotePropertyValue $Value }
    $s | ConvertTo-Json | Set-Content -Encoding UTF8 $Script:StateFile
}

function Ask-YesNo([string]$Question, [bool]$Default = $true) {
    $hint = if ($Default) { '[Y/n]' } else { '[y/N]' }
    while ($true) {
        $a = (Read-Host "$Question $hint").Trim().ToLower()
        if ($a -eq '') { return $Default }
        if ($a -in @('y', 'yes')) { return $true }
        if ($a -in @('n', 'no'))  { return $false }
    }
}

# Run adb WITHOUT -s (connect, pair, start-server, devices). Never throws on adb's harmless stderr chatter.
function AdbRaw {
    $adb = Get-AdbPath
    if (-not $adb) { throw 'adb not found.' }
    $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    try { $out = & $adb @args 2>&1 | ForEach-Object { "$_" } }
    finally { $ErrorActionPreference = $old }
    return $out
}

# Run adb against the saved TV. Returns output as an array of strings (stdout + stderr).
function Adb {
    $adb = Get-AdbPath
    if (-not $adb) { throw 'adb not found. Run 00-setup-and-connect.ps1 first.' }
    $serial = (Read-State).serial
    $pre = @()
    if ($serial) { $pre = @('-s', [string]$serial) }
    $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
    try { $out = & $adb @pre @args 2>&1 | ForEach-Object { "$_" } }
    finally { $ErrorActionPreference = $old }
    return $out
}

# Stop unless the saved TV answers (tries to reconnect once).
function Assert-TvOnline {
    $serial = (Read-State).serial
    if (-not $serial) { throw 'No TV saved yet. Run 00-setup-and-connect.ps1 first.' }
    $st = ((@(Adb get-state)) -join '').Trim()
    if ($st -ne 'device') {
        Write-Host "Reconnecting to $serial ..."
        AdbRaw connect $serial | Out-Null
        Start-Sleep -Seconds 2
        $st = ((@(Adb get-state)) -join '').Trim()
    }
    if ($st -ne 'device') {
        throw "TV not reachable (state '$st'). Is it on, on the same Wi-Fi, with network debugging enabled? Then re-run."
    }
}

# Package names on the TV. $Flags goes straight to `pm list packages`: '' all, '-e' enabled, '-d' disabled,
# '-s' system, '-3' third-party, '-u' including uninstalled-for-user, or a name to filter by.
function Get-Packages([string]$Flags = '') {
    $lines = @(Adb shell "pm list packages $Flags")
    return @($lines | Where-Object { $_ -like 'package:*' } | ForEach-Object { ($_ -replace '^package:', '').Trim() } | Sort-Object -Unique)
}

# Screenshot taken ON the TV (screencap), pulled to work\screenshots. Returns the file path.
function Save-Shot([string]$Name) {
    $safe = $Name -replace '[^\w\.-]', '_'
    $dest = Join-Path $Script:Shots ("{0}-{1}.png" -f (Get-Date -Format 'HHmmss'), $safe)
    Adb shell 'screencap -p /data/local/tmp/tvkit.png' | Out-Null
    Adb pull /data/local/tmp/tvkit.png $dest | Out-Null
    Adb shell 'rm -f /data/local/tmp/tvkit.png' | Out-Null
    if ((Test-Path $dest) -and (Get-Item $dest).Length -gt 1000) {
        Write-Host "  screenshot: $dest" -ForegroundColor DarkGray
    } else {
        Write-Warning 'Screenshot failed or came back empty (some TVs block screencap). Check the TV screen by eye.'
    }
    return $dest
}
